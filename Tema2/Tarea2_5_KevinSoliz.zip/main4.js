
let nombre = prompt("Introduce tu nombre");
console.log(nombre);


let aceptar = confirm("Quieres abandonar el programa?");
if (aceptar)
    alert("Hasta pronto!");
else 
    alert("Pues sigamos!");

console.log('%cFIN DEL PROGRAMA', 'color: blue; font-weight: bold; text-decoration: underline;');